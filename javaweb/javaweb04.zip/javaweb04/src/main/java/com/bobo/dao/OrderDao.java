package com.bobo.dao;

import com.bobo.entity.Order;

public class OrderDao extends BasicDao<Order>{
  
}
