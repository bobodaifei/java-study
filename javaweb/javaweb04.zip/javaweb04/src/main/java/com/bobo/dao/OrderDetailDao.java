package com.bobo.dao;

import com.bobo.entity.OrderDetail;

public class OrderDetailDao extends BasicDao<OrderDetail>{
  
}
