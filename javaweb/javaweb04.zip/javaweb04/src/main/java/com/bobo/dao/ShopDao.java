package com.bobo.dao;

import com.bobo.entity.Shop;

public class ShopDao extends BasicDao<Shop>{
  
}
