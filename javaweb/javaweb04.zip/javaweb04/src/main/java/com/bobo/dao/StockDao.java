package com.bobo.dao;

import com.bobo.entity.Stock;

public class StockDao extends BasicDao<Stock>{
  
}
