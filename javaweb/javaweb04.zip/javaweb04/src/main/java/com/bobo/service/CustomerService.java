package com.bobo.service;

import com.bobo.entity.Customer;

public interface CustomerService {
  public Customer login(Customer customer);

  // public Customer selectById(String customer_no);
}
