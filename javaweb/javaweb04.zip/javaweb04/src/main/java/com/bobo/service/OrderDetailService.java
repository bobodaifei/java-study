package com.bobo.service;

import com.bobo.entity.OrderDetail;

public interface OrderDetailService {

  int add(OrderDetail orderDetail);
  
}
