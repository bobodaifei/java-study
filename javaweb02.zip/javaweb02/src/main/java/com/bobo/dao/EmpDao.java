package com.bobo.dao;

import com.bobo.entity.Emp;

public class EmpDao extends BasicDao<Emp>{
  
}
