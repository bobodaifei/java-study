package com.example.aop;

public @interface EnableLog {
  String value() default "";
}
