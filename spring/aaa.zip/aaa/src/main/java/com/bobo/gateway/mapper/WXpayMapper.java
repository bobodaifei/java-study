package com.bobo.gateway.mapper;

import com.bobo.gateway.entity.WXpay;

public interface WXpayMapper {

  public int insert(WXpay wxpay);

  public int update(WXpay wxpay);

}
