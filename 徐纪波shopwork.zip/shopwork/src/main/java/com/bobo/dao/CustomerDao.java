package com.bobo.dao;

import com.bobo.entity.Customer;

public class CustomerDao extends BasicDao<Customer>{
  
}
