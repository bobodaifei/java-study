package com.bobo.dao;

import com.bobo.entity.Dept;

public class DeptDao extends BasicDao<Dept>{
  
}
