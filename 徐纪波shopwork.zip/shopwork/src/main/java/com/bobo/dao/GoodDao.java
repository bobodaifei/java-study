package com.bobo.dao;

import com.bobo.entity.Good;

public class GoodDao extends BasicDao<Good>{
  
}
