package com.bobo.dao;

import com.bobo.entity.ShopCar;

public class ShopCarDao extends BasicDao<ShopCar>{
  
}
