package com.bobo.service;

import com.bobo.entity.ShopCar;

public interface ShopCarService {

  int add(ShopCar shopCar);

  int update(ShopCar shopCar);

  ShopCar selectOne(ShopCar shopCar);
  
}
