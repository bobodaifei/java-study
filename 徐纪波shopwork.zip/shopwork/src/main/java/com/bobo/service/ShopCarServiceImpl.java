package com.bobo.service;

import com.bobo.dao.ShopCarDao;
import com.bobo.entity.ShopCar;

public class ShopCarServiceImpl implements ShopCarService{

  private ShopCarDao shopCarDao = new ShopCarDao();

  @Override
  public int add(ShopCar shopCar) {
    String sql="INSERT INTO `shop_car` VALUES (?, ?, ?, ?, ?)";
    return shopCarDao.update(sql, shopCar.getCustomer_no(), shopCar.getGood_no(), shopCar.getNum(), shopCar.getPrice(),
        shopCar.getShop_no());
  }

  @Override
  public int update(ShopCar shopCar) {
    String sql = "UPDATE shop_car SET num =?  WHERE customer_no = ? AND good_no = ? AND shop_no = ? ";
    return shopCarDao.update(sql, shopCar.getNum(), shopCar.getCustomer_no(), shopCar.getGood_no(), shopCar.getShop_no());
  }

  @Override
  public ShopCar selectOne(ShopCar shopCar) {
    String sql = "select * from shop_car where customer_no = ? and good_no = ?";
    return shopCarDao.querySingle(sql, ShopCar.class, shopCar.getCustomer_no(), shopCar.getGood_no());
  }
  
}
