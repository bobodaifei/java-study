package com.bobo.servlet;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bobo.entity.ShopCar;
import com.bobo.service.ShopCarService;
import com.bobo.service.ShopCarServiceImpl;

@WebServlet("/shopCar")
public class ShopCarServlet extends HttpServlet {

  private ShopCarService shopCarService = new ShopCarServiceImpl();

  @Override
  protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String method = req.getParameter("method");
    if ("selectPage".equals(method)) {
      // this.selectPage(req, resp);
      return;
    } else if ("put".equals(method)) {
      this.put(req, resp);
    }
  }

  protected void put(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ShopCar shopCar = this.selectOne(req, resp);
    if (shopCar == null) {
      this.add(req, resp);

    } else {
      req.setAttribute("num", shopCar.getNum() + 1);
      this.update(req, resp);
    }
    resp.sendRedirect("/shopwork/good?method=selectPage&shop_no="+ shopCar.getShop_no());
    // req.getRequestDispatcher("/good?method=selectPage").forward(req, resp);
  }

  protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String customer_no = req.getParameter("customer_no");
    String good_no = req.getParameter("good_no");
    String shop_no = req.getParameter("shop_no");
    Integer price = Integer.parseInt(req.getParameter("price"));
    ShopCar shopCar = new ShopCar(customer_no, good_no, 1, price, shop_no);
    shopCarService.add(shopCar);
  }

  private void update(HttpServletRequest req, HttpServletResponse resp) {
    String customer_no = req.getParameter("customer_no");
    String good_no = req.getParameter("good_no");
    String shop_no = req.getParameter("shop_no");
    int num =(int) req.getAttribute("num");
    ShopCar shopCar = new ShopCar(customer_no, good_no, num, shop_no);
    shopCarService.update(shopCar);
  }

  protected ShopCar selectOne(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String customer_no = req.getParameter("customer_no");
    String good_no = req.getParameter("good_no");
    ShopCar shopCar = new ShopCar(customer_no, good_no);
    return shopCarService.selectOne(shopCar);
  }

  // protected long count(HttpServletRequest req, HttpServletResponse resp) throws
  // ServletException, IOException {
  // String customer_no = req.getParameter("customer_no");
  // String good_no = req.getParameter("good_no");
  // String shop_no = req.getParameter("shop_no");
  // Integer price = Integer.parseInt(req.getParameter("price"));
  // //
  // return 0;
  // }

  // protected void selectPage(HttpServletRequest req, HttpServletResponse resp)
  // throws ServletException, IOException {
  // String currentPageStr = req.getParameter("currentPage");
  // String pageSizeStr = req.getParameter("pageSize");
  // int currentPage = 0;
  // int pageSize = 10;
  // if (!(currentPageStr == null || pageSizeStr == null)) {
  // currentPage = Integer.valueOf(currentPageStr);
  // pageSize = Integer.valueOf(pageSizeStr);
  // }
  // long total = shopCarService.selectCount();
  // int begin = (currentPage - 1) * pageSize;

  // if (begin >= total) {
  // currentPage--;
  // begin = begin - pageSize;
  // }
  // if (currentPage < 1) {
  // currentPage = 1;
  // begin = 0;
  // }

  // List<Shop> list = shopCarService.selectPage(begin, pageSize);

  // req.setAttribute("list", list);
  // req.setAttribute("total", total);
  // req.setAttribute("currentPage", currentPage);
  // req.setAttribute("pageSize", pageSize);
  // req.getRequestDispatcher("/shopList.jsp").forward(req, resp);
  // }
}
